# Handoff: Current Research Page

## Overview

A redesigned `/current-research` route for Valérian Teissier's personal site. The page is a live dashboard of research nodes (essays, readings, reviews) with a terminal/scientific aesthetic, an animated canvas nebula background, a multi-layer parallax depth system, and a horizontal scrolling card track on desktop.

---

## About the Design Files

`Current Research v2.html` is a **high-fidelity design reference built in HTML + React/Babel**. It is a prototype showing the intended look, animations, and interactions — not production code to ship directly.

Your task: **recreate this design inside the existing codebase** (`src/routes/current-research.tsx`) using TanStack Router, React, and Tailwind CSS (the project's established stack). The component structure in the HTML maps 1:1 to the existing TSX file — see the mapping table below.

---

## Fidelity

**High-fidelity.** Colors, typography, spacing, animations, and interactions are all final. Recreate pixel-accurately. The one exception is the Tailwind utility class mapping — convert inline styles back to Tailwind utilities where possible, using the project's existing `styles.css` tokens.

---

## Screens / Views

### `/current-research` — Research Dashboard

**Layout (desktop, ≥768px):**
- Full viewport height (`100dvh`), `overflow: hidden`, flex column
- No vertical scroll on desktop. Page is a fixed-height shell.
- Header: ~56px tall
- Title + filters section: ~170px tall
- Cards track: fills remaining height minus 176px (log panel)
- Log panel: fixed at bottom, 11rem collapsed / 100vh expanded

**Layout (mobile, <768px):**
- Normal vertical scroll (`overflow: auto`)
- Cards in a single-column grid
- Log panel fixed at bottom

---

## Component Mapping

The existing `current-research.tsx` components map directly to the new design:

| Old component | New component | Change |
|---|---|---|
| `Stardust` | `NebulaBg` | Full replacement — canvas-based animated nebula |
| `HudOverlay` | `ScientificHud` | Full replacement — SVG scientific overlay with parallax |
| *(new)* | `DeepParallax` | New mid-ground parallax layer |
| `ResearchCard` | `ResearchCard` | Same props; fixed width + height on desktop, flex column layout |
| `CornerTicks` | `CornerTicks` | Identical |
| `ThinkingLog` | `ThinkingLog` | Identical |
| `CurrentResearchPage` | `CurrentResearchPage` | Horizontal scroll track + scrollX state + parallax wiring |

---

## Component Specs

### `NebulaBg`
Canvas element, `position: fixed; inset: 0; z-index: 0`.

Draws on every `requestAnimationFrame`. Uses a seeded PRNG (`mulberry32`, seed `42`) so elements are deterministic and never flash on re-render.

**Background fill:** `#05030e` (near-black with deep indigo tint)

**Layers drawn (all use `globalCompositeOperation = 'lighter'` for additive blending):**

1. **Nebula clouds** — 9 radial gradients, slow drift via `Math.sin/cos`:
   - 6 violet-plum clouds: cores `rgb(118,92,178)` → `rgb(22,10,38)` → transparent
   - 3 amber cores (gold): cores `rgb(192,145,48)` → `rgb(55,36,8)` → transparent
   - Each cloud drifts: `dx = sin(t*0.046 + phase) * 0.017 * W`
   - Plus a bright inner glow for non-gold clouds: `rgba(215,200,240, intensity*0.18)`

2. **Fiber wisps** — 95 quadratic bezier curves, color `rgba(168,150,210, 0.01–0.05)`, lineWidth `0.35`

3. **Stars** — 230 radial gradients, warm-white `rgba(255,252,248,op)` with lavender halo `rgba(220,208,235,op*0.30)`, twinkling via `sin(t * speed + phase)`

Cloud positions (normalized 0–1):
```
{ x:0.20, y:0.32, r:0.44 }  // large violet
{ x:0.62, y:0.22, r:0.35 }
{ x:0.50, y:0.65, r:0.40 }
{ x:0.10, y:0.72, r:0.26 }
{ x:0.78, y:0.58, r:0.28 }
{ x:0.35, y:0.50, r:0.32 }
{ x:0.25, y:0.33, r:0.08 }  // amber core
{ x:0.60, y:0.24, r:0.06 }  // amber core
{ x:0.50, y:0.58, r:0.07 }  // amber core
```

---

### `DeepParallax`
`position: fixed; inset: 0; z-index: 5; overflow: hidden; pointer-events: none`

Contains an SVG spanning `max(W*2.5, 2400)` × `H`.

**Parallax:** `transform: translateX(-scrollX * 0.25)` — moves at 25% of scroll speed.

**Elements** (seeded PRNG, seed `888`, spread across SVG width):
- 40 dots: `r` 0.7–2.5px, `fill: rgba(195,178,225, 0.06–0.20)`
- 22 line segments: length 18–100px, random angle, `stroke: rgba(178,162,212, 0.035–0.095)`, strokeWidth `0.55`
- 5 dashed circle outlines: `r` 25–80px, `stroke: rgba(190,175,222, 0.03–0.08)`, strokeDasharray `2 4`

---

### `ScientificHud`
`position: fixed; inset: 0; z-index: 10; pointer-events: none; mix-blend-mode: screen`

**Parallax:** `transform: translate(mouseX + (-scrollX * 0.50), mouseY)` — 50% scroll speed + mouse parallax.
- Mouse parallax: `(cursor.x - 0.5) * 20` px horizontal, `(cursor.y - 0.5) * 20` px vertical
- Transition: `transform 0.38s cubic-bezier(0.2,0,0,1)`

SVG uses `viewBox="0 0 W H"` matching the live viewport dimensions.

**Elements** (all coordinates are fractions of W/H):

| Element | Position | Style |
|---|---|---|
| Vertical crosshair | x = W*0.34 | `rgba(255,255,255,0.03)`, w=0.6 |
| Horizontal crosshair | y = H*0.44 | `rgba(255,255,255,0.03)`, w=0.6 |
| Measurement circle C1 | cx=W*0.34, cy=H*0.44, r=MIN*0.27 | `rgba(255,255,255,0.06)`, w=0.75 |
| Measurement circle C2 | cx=W*0.58, cy=H*0.36, r=MIN*0.23 | `rgba(255,255,255,0.06)`, w=0.75 |
| 5 radiating lines | from C1/C2 to viewport corners | `rgba(255,255,255,0.07)`, w=0.5 |
| Dots on ray 1 (C1→TL) | 5 dots evenly spaced | `rgba(255,255,255,0.27)`, r=1.7 |
| Dots on ray 4 (C2→TR) | 4 dots evenly spaced | `rgba(255,255,255,0.20)`, r=1.4 |
| Dashed annotation ring A1 | cx=W*0.355, cy=H*0.305, r=54 | `rgba(255,255,255,0.19)`, dasharray `3 3.5` |
| Dashed annotation ring A2 | cx=W*0.565, cy=H*0.265, r=42 | `rgba(255,255,255,0.17)`, dasharray `3 3.5` |
| Inner ring A1 | same cx/cy, r=12 | `rgba(255,255,255,0.24)` solid |
| Inner ring A2 | same cx/cy, r=10 | `rgba(255,255,255,0.24)` solid |
| Crosshair ticks at A1, A2 | ±7px lines | `rgba(255,255,255,0.30)`, w=0.7 |
| Coordinate labels A1 | right of A1 ring | `rgba(255,255,255,0.28)`, 10px Space Mono |
| Coordinate labels A2 | right of A2 ring | `rgba(255,255,255,0.20)`, 9px Space Mono |
| 5× sparkle stars | at A1, A2, C1, C2-offset, ray dot | white fill, 3.5–9.5px arm length |
| Corner readout | top-right | `rgba(255,255,255,0.18)`, 9px Space Mono |
| NODE_FIELD label | bottom-left (above log) | `rgba(255,255,255,0.18)`, 9px Space Mono |

**Sparkle path** (4-pointed star, for arm length `s` at center `cx,cy`):
```
k = s * 0.13
M cx cy-s  C cx+k cy-k  cx+k cy-k  cx+s cy
           C cx+k cy+k  cx+k cy+k  cx   cy+s
           C cx-k cy+k  cx-k cy+k  cx-s cy
           C cx-k cy-k  cx-k cy-k  cx   cy-s  Z
```

---

### `ResearchCard`

**Desktop:** `width: 355px; height: calc(100vh - 402px); min-height: 320px`
**Mobile:** `width: 100%; height: auto`

```
border: 1px solid rgba(255,255,255,0.09)  →  hovered: rgba(52,211,153,0.38)
background: rgba(2,1,14,0.58)
backdrop-filter: blur(16px)
padding: 20px 22px
transition: all 0.26s
transform on hover: translateY(-3px)
box-shadow on hover: 0 0 48px -14px rgba(52,211,153,0.25), 0 0 80px -30px rgba(100,70,180,0.20)
```

Internal layout: `display: flex; flex-direction: column` — abstract grows (`flex: 1`), status+tags pinned to bottom (`margin-top: auto`).

**Type badge colors:**
- ESSAY: border `rgba(52,211,153,0.44)`, text `#34d399`
- READING: border `rgba(255,255,255,0.18)`, text `rgba(255,255,255,0.58)`
- REVIEW: border `rgba(245,158,11,0.44)`, text `#f59e0b`

**Hover coordinate readout:** `position: absolute; top: -18px; right: 0` — appears on hover, Space Mono 10px, color `rgba(52,211,153,0.72)`.

---

### `ResearchCard` — Horizontal scroll track

Cards sit inside a flex row with:
```
overflow-x: auto; overflow-y: hidden
scrollbar-width: none  (hidden scrollbar)
gap: 18px
padding: 8px {sidePadding} {logHeight + 20px}
align-items: center
```

**Scroll progress bar** — 1px line at the top of the track:
```
background: linear-gradient(90deg, rgba(52,211,153,0.5), rgba(100,70,180,0.3))
width: (scrollLeft / maxScroll) * 100%
transition: width 0.1s linear
```

**End-of-track element:** 180px wide spacer with a `> LOAD_MORE_NODES` button and decorative vertical gradient lines.

---

### `ThinkingLog`

`position: fixed; bottom: 0; left: 0; right: 0; z-index: 30`

```
height: 11rem  (collapsed)  →  100vh  (focus mode)
transition: height 0.5s cubic-bezier(0.4,0,0.2,1)
background: rgba(2,1,14,0.92)
backdrop-filter: blur(20px)
border-top: 1px solid rgba(255,255,255,0.08)
```

Header bar: 36px, `border-bottom: 1px solid rgba(255,255,255,0.07)`.
Live indicator: 6px dot, `#34d399`, `animation: pulse 2.2s ease-in-out infinite`.
Log lines: Space Mono 11px, `line-height: 1.75`. Oldest lines fade to `opacity: 0.15`.

---

## State Management

New state vs the existing file:

```ts
const [scrollX, setScrollX] = useState(0);          // horizontal scroll position
const [dim, setDim] = useState({ W, H });            // live viewport dimensions
const [isMobile, setIsMobile] = useState(false);     // breakpoint flag (< 768px)
```

`scrollX` is persisted to `localStorage` key `'cr-sx'` and restored on mount.

Pass `scrollX`, `W`, `H` down to `DeepParallax` and `ScientificHud`.

---

## Design Tokens

| Token | Value |
|---|---|
| Background | `#05030e` |
| Foreground | `rgba(255,255,255,0.85)` |
| Accent (emerald) | `#34d399` |
| Accent (amber) | `#f59e0b` |
| Card bg | `rgba(2,1,14,0.58)` |
| Border default | `rgba(255,255,255,0.09)` |
| Border hover | `rgba(52,211,153,0.38)` |
| Font sans | Space Grotesk (existing codebase may use different — match the existing `--font-sans`) |
| Font mono | Space Mono (existing codebase may use different — match `--font-mono`) |
| Nebula violet core | `rgb(118,92,178)` |
| Nebula amber core | `rgb(192,145,48)` |

---

## Animations

| Name | Properties | Duration | Easing |
|---|---|---|---|
| `fadeIn` | `opacity 0→1`, `translateY 5px→0` | 0.5s | ease-out |
| `blink` | `opacity 1→0→1` (step) | 1s | step-end |
| `pulse` | `opacity 1→0.2→1` | 2.2s | ease-in-out |
| Card hover lift | `translateY -3px` | 0.26s | default |
| HUD parallax | `translate(tx, ty)` | 0.38s | `cubic-bezier(0.2,0,0,1)` |
| Log expand | `height 11rem→100vh` | 0.5s | `cubic-bezier(0.4,0,0.2,1)` |
| Progress bar | `width %` | 0.1s | linear |

---

## Assets

No external image assets. All visuals are generated procedurally:
- Nebula: HTML5 Canvas + `requestAnimationFrame`
- HUD + DeepParallax: inline SVG
- All icons: Unicode characters (`←`, `⤢`, `×`, `>`)

Fonts loaded from Google Fonts:
```html
https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Space+Mono&display=swap
```
Check whether the existing codebase already loads these. If not, add them (or substitute the project's existing font stack and adjust sizes accordingly).

---

## Files

| File | Description |
|---|---|
| `Current Research v2.html` | High-fidelity prototype — the source of truth for this handoff |
| `Current Research.html` | v1 prototype (vertical grid, blue nebula) — for reference only |
| `current-research.tsx` | Existing production file to be updated |
| `styles.css` | Existing design tokens (Tailwind + CSS custom properties) |

---

## Implementation Notes

1. **Canvas in SSR** — if the project uses SSR, wrap `NebulaBg` in a client-only guard (`useEffect` mount check or a dynamic import with `ssr: false`).
2. **Tailwind classes** — the prototype uses inline styles. Map back to Tailwind utilities using the project's token system in `styles.css`. E.g. `rgba(52,211,153,0.38)` → `border-emerald-400/40`.
3. **Horizontal scroll on touch** — the `hscroll` container hides the native scrollbar but touch/trackpad swipe should work natively. On iOS, add `-webkit-overflow-scrolling: touch` if needed.
4. **Viewport height** — use `100dvh` (dynamic viewport height) not `100vh` to avoid mobile browser chrome issues.
5. **PRNG** — copy the `mulberry32` seeded PRNG helper as-is. It must be stable across renders to avoid nebula flicker.
